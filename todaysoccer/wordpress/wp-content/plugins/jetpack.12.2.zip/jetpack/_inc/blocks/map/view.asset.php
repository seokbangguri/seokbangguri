<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '0eb1ca92e9c1a2ddb7ac');
