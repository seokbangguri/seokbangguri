<?php return array('dependencies' => array('wp-polyfill'), 'version' => '9cdef11947b6fc564b08');
