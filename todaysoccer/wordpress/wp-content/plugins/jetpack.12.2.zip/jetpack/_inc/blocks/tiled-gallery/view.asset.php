<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '8c5e57e26aa3d75a05af');
