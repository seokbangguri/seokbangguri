<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '94f2d56b2ffdd41b435a');
