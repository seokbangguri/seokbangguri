<?php return array('dependencies' => array('wp-polyfill'), 'version' => 'bd96cc9f22240a4c6d05');
