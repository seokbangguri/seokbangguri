<?php return array('dependencies' => array('wp-polyfill'), 'version' => '6fb617b85c0a7773a033');
