<?php return array('dependencies' => array('wp-polyfill'), 'version' => '42a51ad15771bc6432ef');
