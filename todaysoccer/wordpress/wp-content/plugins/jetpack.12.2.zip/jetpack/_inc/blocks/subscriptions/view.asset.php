<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '3a52c74075e54a62b583');
