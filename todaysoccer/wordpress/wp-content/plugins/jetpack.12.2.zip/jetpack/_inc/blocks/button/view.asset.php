<?php return array('dependencies' => array('wp-polyfill'), 'version' => '7055746471a66eb41987');
